/* GALLERY ITEMS - add a new line to add a photo/video.
   cat: one of the category names in the filter list (see CATEGORIES below)
   type: "image" or "video"; src: full image or video file; thumb: preview image
   Put your own files in the /media folder, e.g. src: "media/wedding-1.jpg" */
var CATEGORIES = ["Wedding","Pre-Wedding","Engagement","Haldi","Mehndi","Sangeet","Reception","Destination Wedding","Birthday","Corporate Events","Anniversary"];
var KEYS = ["wed","pre","eng","hal","meh","san","rec","des","bir","cor","ann"];
var VIDEO = "https://www.w3schools.com/html/mov_bbb.mp4";
function pic(s, w, h) { return "https://picsum.photos/seed/" + s + "/" + w + "/" + h; }
var GALLERY = [];
CATEGORIES.forEach(function (c, i) {
  var k = KEYS[i];
  GALLERY.push({ id: k + "1", cat: c, type: "image", src: pic(k + "1", 1600, 2000), thumb: pic(k + "1", 900, 1200), title: c });
  GALLERY.push({ id: k + "2", cat: c, type: "image", src: pic(k + "2", 2000, 1400), thumb: pic(k + "2", 900, 650), title: c });
  GALLERY.push({ id: k + "3", cat: c, type: "video", src: VIDEO, thumb: pic(k + "3", 900, 650), title: c + " Film" });
});
