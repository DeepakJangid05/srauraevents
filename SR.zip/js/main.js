(function () {
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  /* header + mobile menu */
  var header = $("#header");
  var onScroll = function () { header.classList.toggle("solid", window.scrollY > 40); };
  onScroll(); window.addEventListener("scroll", onScroll);
  $("#navToggle").addEventListener("click", function () { $("#mainNav").classList.toggle("open"); header.classList.add("solid"); });
  $("#year").textContent = new Date().getFullYear();

  /* page hero backgrounds (kept out of inline CSS) */
  $$("[data-bg]").forEach(function (el) { el.style.backgroundImage = "url(" + el.dataset.bg + ")"; });

  /* scroll reveal */
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
  }, { threshold: 0.15 }) : null;
  function watch() { $$(".reveal:not(.in)").forEach(function (el) { io ? io.observe(el) : el.classList.add("in"); }); }
  watch();

  /* modals */
  var lb = document.createElement("div"); lb.className = "modal";
  lb.innerHTML = '<button class="m-close" aria-label="Close">&times;</button><button class="m-prev" aria-label="Previous">&lsaquo;</button><img alt=""><button class="m-next" aria-label="Next">&rsaquo;</button>';
  var vm = document.createElement("div"); vm.className = "modal";
  vm.innerHTML = '<button class="m-close" aria-label="Close">&times;</button><video controls></video>';
  document.body.appendChild(lb); document.body.appendChild(vm);
  var list = [], idx = 0;
  function showImg() { var it = list[idx]; var im = $("img", lb); im.src = it.src; im.alt = it.title; }
  function openImg(items, i) { list = items; idx = i; showImg(); lb.classList.add("open"); }
  function step(d) { idx = (idx + d + list.length) % list.length; showImg(); }
  function closeAll() { lb.classList.remove("open"); vm.classList.remove("open"); var v = $("video", vm); v.pause(); v.removeAttribute("src"); }
  function openVid(src) { var v = $("video", vm); v.src = src; vm.classList.add("open"); v.play(); }
  $(".m-prev", lb).onclick = function (e) { e.stopPropagation(); step(-1); };
  $(".m-next", lb).onclick = function (e) { e.stopPropagation(); step(1); };
  $$(".m-close").forEach(function (b) { b.onclick = closeAll; });
  [lb, vm].forEach(function (m) { m.addEventListener("click", function (e) { if (e.target === m) closeAll(); }); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeAll();
    if (lb.classList.contains("open")) { if (e.key === "ArrowRight") step(1); if (e.key === "ArrowLeft") step(-1); }
  });

  /* gallery grids */
  function renderGrid(grid, items) {
    var images = items.filter(function (i) { return i.type === "image"; });
    grid.innerHTML = "";
    items.forEach(function (it) {
      var b = document.createElement("button"); b.className = "tile";
      b.innerHTML = '<img loading="lazy" src="' + it.thumb + '" alt="' + it.title + '"><span class="cap">' + it.title + "</span>" + (it.type === "video" ? '<span class="play">&#9654;</span>' : "");
      b.onclick = function () { it.type === "video" ? openVid(it.src) : openImg(images, images.indexOf(it)); };
      grid.appendChild(b);
    });
  }
  var grid = $("[data-gallery]");
  if (grid && typeof GALLERY !== "undefined") {
    if (grid.dataset.ids) {
      var ids = grid.dataset.ids.split(",");
      renderGrid(grid, ids.map(function (id) { return GALLERY.filter(function (g) { return g.id === id; })[0]; }).filter(Boolean));
    } else {
      var fb = $("#filters");
      ["All"].concat(CATEGORIES).forEach(function (c, i) {
        var b = document.createElement("button"); b.textContent = c; if (!i) b.className = "on";
        b.onclick = function () {
          $$("button", fb).forEach(function (x) { x.classList.remove("on"); }); b.classList.add("on");
          renderGrid(grid, c === "All" ? GALLERY : GALLERY.filter(function (g) { return g.cat === c; }));
          grid.classList.remove("fade"); void grid.offsetWidth; grid.classList.add("fade");
        };
        fb.appendChild(b);
      });
      renderGrid(grid, GALLERY);
    }
  }

  /* featured films */
  var films = $("#films");
  if (films) {
    GALLERY.filter(function (g) { return g.type === "video"; }).slice(0, 3).forEach(function (f, i) {
      var b = document.createElement("button"); b.className = "film reveal";
      b.innerHTML = '<img loading="lazy" src="' + f.thumb + '" alt="' + f.title + '"><span class="play">&#9654;</span><span class="film-label">' + (i === 2 ? "Event Highlight" : "Wedding Film") + " &middot; " + f.cat + "</span>";
      b.onclick = function () { openVid(f.src); };
      films.appendChild(b);
    });
    watch();
  }

  /* testimonials */
  var qs = $$("#quotes blockquote"), dots = $("#quoteDots"), qi = 0, timer;
  if (qs.length) {
    var go = function (n) { qi = n; qs.forEach(function (q, i) { q.classList.toggle("active", i === n); }); $$("button", dots).forEach(function (d, i) { d.classList.toggle("on", i === n); }); };
    qs.forEach(function (_, i) { var d = document.createElement("button"); d.setAttribute("aria-label", "Testimonial " + (i + 1)); d.onclick = function () { go(i); }; dots.appendChild(d); });
    go(0); timer = setInterval(function () { go((qi + 1) % qs.length); }, 6000);
  }

  /* contact form */
  var form = $("#inquiryForm");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var f = form.elements, ok = true;
      function check(name, valid, msg) {
        var box = f[name].closest(".fld"); box.classList.toggle("bad", !valid);
        $("small", box).textContent = valid ? "" : msg; if (!valid) ok = false;
      }
      check("name", f.name.value.trim().length >= 2, "Please enter your full name");
      check("email", /^\S+@\S+\.\S+$/.test(f.email.value), "Enter a valid email");
      check("phone", /^[+\d][\d\s-]{7,15}$/.test(f.phone.value), "Enter a valid phone number");
      check("type", !!f.type.value, "Select an event type");
      check("message", f.message.value.trim().length >= 10, "Tell us a little more (10+ characters)");
      if (ok) { /* connect to your backend / form service here */ $("#thanks").classList.add("show"); form.reset(); }
    });
  }
})();
